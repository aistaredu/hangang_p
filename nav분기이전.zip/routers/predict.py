# =============================================================
# routers/predict.py
# ML 혼잡도 예측 API
# =============================================================
# 📌 5회차에서 완성되는 API:
#   POST /predict → 주차장 ID + 날짜 입력 → 혼잡도 % + 잔여 면수 반환
#
# 📌 ML 모델 접근 방식:
#   모델은 main.py의 lifespan에서 서버 시작 시 한 번 로드됩니다.
#   각 요청에서 request.app.state.ml_model 로 접근합니다.
#   요청마다 모델을 파일에서 읽으면 매우 느리므로 이 방식을 사용합니다.
#
# 📌 피처 구성 (학습 시와 완전히 동일해야 함):
#   [lot_id, capacity, month, day_of_week, is_weekend, week_of_year, is_holiday]
#   순서가 다르면 예측값이 엉뚱하게 나옵니다.
# =============================================================

from datetime import date
import holidays as kr_holidays  # 한국 공휴일 계산 라이브러리

from fastapi import APIRouter, HTTPException, Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session
from starlette import status

from database.db_connection import get_session
from models.models import ParkingInfo
from schema.request import PredictRequest
from schema.response import PredictResponse

# APIRouter: 관련 API를 하나의 파일로 묶은 단위
# tags=["예측"]: Swagger UI(/docs)에서 "예측" 그룹으로 분류
router = APIRouter(tags=["예측"])


# =============================================================
# 혼잡도 예측 API
# POST /predict
# =============================================================
@router.post(
    "/predict",
    response_model=PredictResponse,      # 응답 형식 자동 검증 + Swagger 문서 생성
    status_code=status.HTTP_200_OK,
)
def predict_handler(
    body   : PredictRequest,             # { lot_id: int, target_date: date }
    request: Request,                    # app.state.ml_model 접근용 — FastAPI Request 객체
    session: Session = Depends(get_session),
):
    """
    주차장 ID와 날짜를 받아서 ML 모델로 혼잡도를 예측합니다.

    처리 순서:
        1) 서버에 ML 모델이 로드되어 있는지 확인
        2) 주차장 정보(capacity 등) DB에서 조회
        3) 날짜 → 피처 벡터 자동 계산
        4) 모델.predict(X) 호출
        5) 혼잡도% + 잔여 면수 계산 후 반환
    """

    # ── 1) ML 모델 확인 ───────────────────────────────────────
    # main.py lifespan에서 app.state.ml_model 에 로드됩니다.
    # getattr(객체, 속성명, 기본값): 속성이 없을 때 기본값 반환 (AttributeError 방지)
    model = getattr(request.app.state, "ml_model", None)
    if model is None:
        # 503 Service Unavailable: 서버는 살아있지만 서비스 불가 상태
        # models_pkl/hangang_parking.pkl 파일이 없거나 로드 실패 시 발생
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="ML 모델이 로드되지 않았습니다. ml/train.py 를 먼저 실행하세요.",
        )

    # ── 2) 주차장 정보 조회 ────────────────────────────────────
    # capacity(총 주차면수)를 피처와 잔여 면수 계산에 사용합니다.
    stmt = select(ParkingInfo).where(ParkingInfo.id == body.lot_id)
    lot  = session.scalar(stmt)  # 없으면 None
    if not lot:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="주차장을 찾을 수 없습니다",
        )

    # ── 3) 날짜 → 피처 자동 계산 ─────────────────────────────
    target = body.target_date  # date 객체 (예: date(2025, 8, 15))

    # isoweekday(): ISO 표준 요일 (1=월요일 ~ 7=일요일)
    # MySQL DAYOFWEEK()는 1=일~7=토 이지만
    # Python isoweekday()는 1=월~7=일로 다릅니다.
    # 학습 시 어떤 방식을 사용했는지와 여기서 일치해야 합니다.
    day_of_week  = target.isoweekday()          # 1(월) ~ 7(일)
    is_weekend   = 1 if day_of_week >= 6 else 0 # 6=토, 7=일 → 주말
    week_of_year = target.isocalendar()[1]       # 연간 몇 번째 주 (1~53)

    # 공휴일 여부 확인
    # kr_holidays.KR(): 한국 공휴일 딕셔너리 생성 (대체공휴일 포함)
    # target in kr_holidays.KR(): 해당 날짜가 공휴일이면 True
    is_holiday = 1 if target in kr_holidays.KR() else 0

    # ── 4) 피처 벡터 구성 ────────────────────────────────────
    # 학습 시 사용한 피처 순서와 반드시 동일해야 합니다.
    # ml/train.py의 SELECT 컬럼 순서: lot_id, capacity, month, day_of_week,
    #                                  is_weekend, week_of_year, is_holiday
    X = [[
        body.lot_id,        # 주차장 ID (1~11)
        int(lot.capacity),  # 총 주차면수 (Decimal → int 변환)
        target.month,       # 월 (1~12)
        day_of_week,        # 요일 (1~7)
        is_weekend,         # 주말 여부 (0/1)
        week_of_year,       # 연간 주차 (1~53)
        is_holiday,         # 공휴일 여부 (0/1)
    ]]
    # X 형태: [[1, 458, 8, 5, 0, 33, 1]]
    # 2차원 리스트인 이유: scikit-learn은 (n_samples, n_features) 형태를 요구

    # ── 5) 예측 실행 ─────────────────────────────────────────
    # model.predict(X): 혼잡도 % 예측
    # 반환: numpy 배열 [예측값] → [0] 으로 첫 번째 값 추출 → float 변환
    occupancy_pct = float(model.predict(X)[0])

    # 클리핑: 모델이 0% 미만 또는 100% 초과로 예측하는 경우 보정
    # max(0.0, ...) : 음수 방지
    # min(100.0, ...) : 100% 초과 방지
    occupancy_pct = max(0.0, min(100.0, occupancy_pct))

    # ── 6) 잔여 면수 계산 ────────────────────────────────────
    # 혼잡도 80% → 잔여 20% → 잔여 면수 = capacity × 0.20
    predicted_spaces = int(int(lot.capacity) * (1 - occupancy_pct / 100))

    # ── 7) 응답 반환 ─────────────────────────────────────────
    return PredictResponse(
        lot_id          =body.lot_id,
        lot_name        =lot.lot_name,
        target_date     =body.target_date,
        capacity        =int(lot.capacity),
        predicted_spaces=predicted_spaces,
        occupancy_pct   =round(occupancy_pct, 1),  # 소수점 1자리로 반올림
    )
